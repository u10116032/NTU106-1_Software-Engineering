public class Main {
	public static void main(String[] args)
	{
		OnlineShoppingSite onlineShoppingSite = new OnlineShoppingSite();
		onlineShoppingSite.start(args[0]);
	}
}