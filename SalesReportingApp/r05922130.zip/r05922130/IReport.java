import java.util.*;

public interface IReport{

	void refresh(List<String> tokens);

	boolean display();

}