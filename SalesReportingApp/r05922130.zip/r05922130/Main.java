public class Main{

	public static void main(String args[])
	{
		Application application = new Application(args[0]);
	}
}